<?php $__env->startSection("title","home"); ?>
<?php $__env->startSection('home'); ?>
<div class="row d-flex justify-content-center">
    <div class="col-md-4">
        <div class="card shadow" style="width: 18rem;">
            <div class="card-body">
                <h5 class="card-title">Total Karyawan</h5>
                <h4 class="card-subtitle mb-2 text-muted">500</h4>
            </div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card shadow" style="width: 18rem;">
            <div class="card-body">
                <h5 class="card-title">Total Perusahaan</h5>
                <h4 class="card-subtitle mb-2 text-muted">4</h4>
            </div>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts/main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\RPL-main\resources\views/home.blade.php ENDPATH**/ ?>