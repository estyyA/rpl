<?php $__env->startSection("title", "Daftar Karyawan"); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mt-4">
        <h1>Daftar Karyawan</h1>

        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <!-- Tombol Tambah -->
        <div class="mb-3">
            <a href="<?php echo e(route('karyawan.create')); ?>" class="btn btn-primary">Tambah Karyawan</a>
        </div>

        <!-- Tabel Karyawan -->
        <table class="table table-bordered">
            <thead class="thead-dark">
                <tr>
                    <th>Nama</th>
                    <th>Nama Bank</th>
                    <th>No Rekening</th>
                    <th>Status</th>
                    <th>Department</th>
                    <th>Joining Date</th>
                    <th>Perusahaan</th> <!-- Kolom perusahaan ditambahkan -->
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $karyawans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $karyawan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($karyawan->nama); ?></td>
                        <td><?php echo e($karyawan->nama_bank); ?></td>
                        <td><?php echo e($karyawan->no_rekening); ?></td>
                        <td><?php echo e($karyawan->status); ?></td>
                        <td><?php echo e($karyawan->department); ?></td>
                        <td><?php echo e($karyawan->joining_date); ?></td>
                        <td>
                            <!-- Menampilkan Nama Perusahaan yang terkait -->
                            <?php if($karyawan->perusahaan): ?>
                                <?php echo e($karyawan->perusahaan->nama_perusahaan); ?>

                            <?php else: ?>
                                Belum ada perusahaan
                            <?php endif; ?>
                        </td>
                        <td>
                            <!-- Tombol Edit -->
                            <a href="<?php echo e(route('karyawan.edit', $karyawan->id)); ?>" class="btn btn-warning btn-sm">Edit</a>

                            <!-- Tombol Hapus -->
                            <form action="<?php echo e(route('karyawan.destroy', $karyawan->id)); ?>" method="POST" style="display: inline-block;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Yakin ingin menghapus karyawan ini?')">Hapus</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="7" class="text-center">Belum ada data karyawan.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\RPL-main 1- Copy\resources\views/daftarKaryawan.blade.php ENDPATH**/ ?>