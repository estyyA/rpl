<?php $__env->startSection("title","daftarKaryawan"); ?>
<?php $__env->startSection("daftarKaryawan"); ?>
<div class="card">
    <div class="card-body">
        <table id="example" class="display" style="width:100%">
            <thead>
                <tr>
                    <th>Nama Karyawan</th>
                    <th>Status</th>
                    <th>Department</th>
                    <th>Joining date</th>
                    <th>Peran</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>SongKang</td>
                    <td>Part Time</td>
                    <td>IT</td>
                    <td>01/10/2019</td>
                    <td>Staff IT</td>
                </tr>
            </tbody>
            <tfoot>
                <tr>
                    <th>Nama Karyawan</th>
                    <th>Status</th>
                    <th>Department</th>
                    <th>Joining date</th>
                    <th>Peran</th>
                </tr>
            </tfoot>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts/main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\RPL-main\resources\views/daftarKaryawan.blade.php ENDPATH**/ ?>