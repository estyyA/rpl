<?php $__env->startSection('title', 'Edit Karyawan'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <h1>Edit Karyawan</h1>
    <form action="<?php echo e(route('karyawan.update', $karyawan->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <!-- Input Nama Karyawan -->
        <div class="form-group">
            <label>Nama</label>
            <input type="text" name="nama" class="form-control" value="<?php echo e(old('nama', $karyawan->nama)); ?>" required>
        </div>

        <!-- Input No Rekening -->
        <div class="form-group">
            <label>No Rekening</label>
            <input type="text" name="no_rekening" class="form-control" value="<?php echo e(old('no_rekening', $karyawan->no_rekening)); ?>" required>
        </div>

        <!-- Input Status -->
        <div class="form-group">
            <label>Status</label>
            <select name="status" class="form-control" required>
                <option value="Aktif" <?php echo e(old('status', $karyawan->status) == 'Aktif' ? 'selected' : ''); ?>>Aktif</option>
                <option value="Non-Aktif" <?php echo e(old('status', $karyawan->status) == 'Non-Aktif' ? 'selected' : ''); ?>>Non-Aktif</option>
            </select>
        </div>

        <!-- Input Department -->
        <div class="form-group">
            <label>Department</label>
            <select name="department" class="form-control" required>
                <option value="HRD" <?php echo e(old('department', $karyawan->department) == 'HRD' ? 'selected' : ''); ?>>HRD</option>
                <option value="Finance" <?php echo e(old('department', $karyawan->department) == 'Finance' ? 'selected' : ''); ?>>Finance</option>
                <option value="IT" <?php echo e(old('department', $karyawan->department) == 'IT' ? 'selected' : ''); ?>>IT</option>
                <option value="Marketing" <?php echo e(old('department', $karyawan->department) == 'Marketing' ? 'selected' : ''); ?>>Marketing</option>
                <option value="Sales" <?php echo e(old('department', $karyawan->department) == 'Sales' ? 'selected' : ''); ?>>Sales</option>
            </select>
        </div>

        <!-- Input Joining Date -->
        <div class="form-group">
            <label>Joining Date</label>
            <input type="date" name="joining_date" class="form-control" value="<?php echo e(old('joining_date', $karyawan->joining_date)); ?>" required>
        </div>

        <!-- Dropdown Nama Bank -->
        <div class="form-group">
            <label>Nama Bank</label>
            <select name="nama_bank" class="form-control" required>
                <option value="BCA" <?php echo e(old('nama_bank', $karyawan->nama_bank) == 'BCA' ? 'selected' : ''); ?>>BCA</option>
                <option value="Mandiri" <?php echo e(old('nama_bank', $karyawan->nama_bank) == 'Mandiri' ? 'selected' : ''); ?>>Mandiri</option>
                <option value="BNI" <?php echo e(old('nama_bank', $karyawan->nama_bank) == 'BNI' ? 'selected' : ''); ?>>BNI</option>
                <option value="BRI" <?php echo e(old('nama_bank', $karyawan->nama_bank) == 'BRI' ? 'selected' : ''); ?>>BRI</option>
            </select>
        </div>

        <!-- Input Manual Nama Perusahaan -->
        <select name="perusahaan_id" class="form-control" required>
            <option value="">--Pilih Perusahaan--</option>
            <?php $__currentLoopData = $perusahaans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perusahaan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($perusahaan->id); ?>" <?php echo e(old('perusahaan_id') == $perusahaan->id ? 'selected' : ''); ?>>
                    <?php echo e($perusahaan->nama_perusahaan); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>


        <!-- Error Handling -->
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <!-- Tombol Simpan -->
        <button type="submit" class="btn btn-success">Simpan</button>
        <a href="<?php echo e(route('karyawan.index')); ?>" class="btn btn-secondary">Batal</a>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\RPL-main 1- Copy\resources\views/karyawan/edit.blade.php ENDPATH**/ ?>