<?php $__env->startSection('title', 'Tambah Perusahaan'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <h1>Tambah Perusahaan</h1>
    <form action="<?php echo e(route('perusahaan.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label>Nama Perusahaan</label>
            <input type="text" name="nama_perusahaan" class="form-control" value="<?php echo e(old('nama_perusahaan')); ?>" required>
        </div>
        <div class="form-group">
            <label>Nama Bank</label>
            <input type="text" name="nama_bank" class="form-control" value="<?php echo e(old('nama_bank')); ?>" required>
        </div>
        <div class="form-group">
            <label>No. Rekening</label>
            <input type="text" name="rekening" class="form-control" value="<?php echo e(old('rekening')); ?>" required>
        </div>
        <button type="submit" class="btn btn-success">Simpan</button>
        <a href="<?php echo e(route('perusahaan.index')); ?>" class="btn btn-secondary">Batal</a>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\RPL-main 1- Copy\resources\views/perusahaan/create.blade.php ENDPATH**/ ?>