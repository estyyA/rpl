<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// routes/web.php

use App\Http\Controllers\PageController;

Route::get('/', [PageController::class, 'home']);
Route::get('/daftarKaryawan', [PageController::class, 'daftarKaryawan']);
Route::get('/daftarPerusahaan', [PageController::class, 'daftarPerusahaan'])->name('daftarPerusahaan');

Route::get('/karyawan', [PageController::class, 'daftarKaryawan'])->name('karyawan.index');
Route::get('/karyawan/create', [PageController::class, 'createKaryawan'])->name('karyawan.create');
Route::post('/karyawan', [PageController::class, 'storeKaryawan'])->name('karyawan.store');
Route::get('/karyawan/{karyawan}/edit', [PageController::class, 'editKaryawan'])->name('karyawan.edit');
Route::put('karyawan/{karyawan}', [PageController::class, 'updateKaryawan'])->name('karyawan.update');
Route::delete('/karyawan/{karyawan}', [PageController::class, 'destroyKaryawan'])->name('karyawan.destroy');

Route::get('/perusahaan', [PageController::class, 'daftarPerusahaan'])->name('perusahaan.index');
Route::get('/perusahaan/create', [PageController::class, 'createPerusahaan'])->name('perusahaan.create');
Route::post('/perusahaan', [PageController::class, 'storePerusahaan'])->name('perusahaan.store');
Route::get('/perusahaan/{perusahaan}/edit', [PageController::class, 'editPerusahaan'])->name('perusahaan.edit');
Route::put('/perusahaan/{perusahaan}', [PageController::class, 'updatePerusahaan'])->name('perusahaan.update');
Route::delete('/perusahaan/{perusahaan}', [PageController::class, 'destroyPerusahaan'])->name('perusahaan.destroy');



